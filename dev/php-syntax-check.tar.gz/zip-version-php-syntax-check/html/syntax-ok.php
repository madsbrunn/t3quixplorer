<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>PHP syntax check: <?php echo $hname; ?> is OK :-)</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="stylesheet" href="<?php echo STYLE_SHEET; ?>" type="text/css">
<style type="text/css">
<!--
.style1 {font-size: larger}
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000">
<font size="-1" face="Arial,Helvetica"><?php echo BREADCRUMBS; ?></font>
<h1>PHP syntax check: <?php echo $hname; ?> is OK :-)</h1>
<p>
No errors were found, but note this is just a syntax check - there may be other errors or problems that will only appear when you upload and run the PHP script.
</p>
<p>
Also note that this file was check against PHP <?php echo phpversion(); ?>.
There are slight syntax differences between versions.
</p>
<p>If you are a beginner try the <a href="../">PHP tutorial</a> on this site </p>
<form name="form1" method="get" action="syntax-check.php">
  <input type="submit" name="Submit" value="Check another file">
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
 <hr>
<table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr>
      
    <td align="left"><font
size="-1">http://www.meandeviation.com/tutorials/learnphp/php-syntax-check/</font> 
    </td>
      
    <td align="right"><font size="-1"><a
href="http://www.hcibook.com/alan/">Alan Dix</a> &copy; 2005</font> </td>
    </tr>
</table>

</body>
</html>
