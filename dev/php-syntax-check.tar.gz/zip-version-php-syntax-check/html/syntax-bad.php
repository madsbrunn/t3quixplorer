<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>PHP syntax check: <?php echo $hname; ?> Failed :-(</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="stylesheet" href="<?php echo STYLE_SHEET; ?>" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<font size="-1" face="Arial,Helvetica"><?php echo BREADCRUMBS; ?></font>
<h1>PHP syntax check: <?php echo $hname; ?> Failed :-(</h1>
<h3>Errors:</h3>
<blockquote>
<pre>
<?php
	error_list();
?>
</pre>
</blockquote>
<p>If you are unsure of the correct syntax look at the <a href="http://www.php.net/manual/en/langref.php" target="_new">Language Reference</a> section in the PHP documentation.</p>
<p>
Also note that this file was check against PHP <?php echo phpversion(); ?>.
There are slight syntax differences between versions.
</p>
<p>If you are a beginner try the <a href="../">PHP tutorial</a> on this site </p>
<form name="form1" method="get" action="syntax-check.php">
  <input type="submit" name="Submit" value="Check another file">
</form>
<h3>Your PHP source:</h3>
<?php
if ( $err_line_ct > 0 ) :
?>
<p>Note that the line numbers reported for errors may not be where the real problem lies. For example if you leave out a semicolon ";" at the end of a line the syntax error will normally be reported at the next line.</p>
<p>Mismatched curly brackets "{}" can be especially problematic.
  A missing "}" may show up as an error at the end of the file
  - when it notices there are not enough closing brackets!
  Alternatively if you omit an open "{" or have an extra "}" this
  will usually show up when you hit the outermost "}".
</p>
<p>
So treat any highlighted lines
below as indicators of where an error may be ... but not necessarily <em>exactly</em> where!
</p>
<?php
endif;  // err_line_ct > 0
//readfile($tmp_name);
?>
<blockquote>
<pre>
<?php
	source_list();
?>
</pre>
</blockquote>
<p>&nbsp;</p>
 <hr>
<table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr>
      
    <td align="left"><font
size="-1">http://www.meandeviation.com/tutorials/learnphp/php-syntax-check/</font> 
    </td>
      
    <td align="right"><font size="-1"><a
href="http://www.hcibook.com/alan/">Alan Dix</a> &copy; 2005</font> </td>
    </tr>
</table>

</body>
</html>
