<?php

// for parsing the PHP syntax check output

define('OK_LINE_START','No syntax errors detected in');
define('ON_LINE_PATTERN','/on line <b>([0-9]*)<\\/b>/');

// locations of items on local machine

define('TMPDIR',"/tmp");
define('PHP_CMD',"/usr/bin/php"); // path to command line version of PHP on this system

define('DOS2UNIX','dos2unix');   //  CRLF => LF
define('MAC2UNIX','mac2unix');   //  CR => LF

// local URLs

define('SCRIPT_BASE',"http://www.meandeviation.com/tutorials/learnphp/php-syntax-check/");
define('IMAGE_BASE', SCRIPT_BASE . "icon/");
//define('STYLE_SHEET',"../../../styles/learnphp-style.css");
define('STYLE_SHEET',"styles/learnphp-style.css");

define('BREADCRUMBS',"<a href=\"http://www.meandeviation.com/\">meandeviation.com</a> &gt; " .
            "<a href=\"http://www.meandeviation.com/tutorials/learnphp/\">learn php</a> &gt; " .
            "<a href=\"http://www.meandeviation.com/utils/php-syntax-check/\">php syntax check</a>"
			);

// output formatting 

define('HIGHLIGHT_COLOR','#CC0000');
define('OK_PREFIX',"<img src=\"" . IMAGE_BASE . "invis.gif\" width=\"9\" height=\"9\">&nbsp;");
define('ERR_PREFIX',"<img src=\"" . IMAGE_BASE . "right-red-tri.gif\" width=\"9\" height=\"9\">&nbsp;");

?>