<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Syntax Check PHP File</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="PHP syntax check, syntax errors in PHP">
<meta name="description" content="Introductory tutorial of basic PHP for web scripting.">

<link rel="stylesheet" href="../../../styles/learnphp-style.css" type="text/css">
<style type="text/css">
<!--
.bold {
	color: #993300;
	font-weight: bold;
}
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000">
<font size="-1" face="Arial,Helvetica"><a
href="http://www.meandeviation.com/">meandeviation.com</a> &gt;
<a href="http://www.meandeviation.com/tutorials/learnphp/">learn php</a> &gt; 
php syntax check
</font>
<h1>Syntax Check PHP File</h1>
<!-- The data encoding type, enctype, MUST be specified as below -->
<p>Many PHP systems are configured not to show syntax errors (or other errors) on production web servers. If you are running a separate development server or running a server on your own PC you can set the <a href="http://www.php.net/manual/en/ref.errorfunc.php#ini.display-errors" target="_new">display_errors</a> flag to true in php.ini. This will also make it easier to check other kinds of errors. </p>
<p>However, if you cannot do this for some reason, or you just want a quick check of the PHP sytax, then this page is for you!</p>
<p>Simply select the PHP file you would like below and then press 'Check this File'. This will do a syntax check and show you  any (usually the first!) syntax errors in your file. As syntax errors are reported with line numbers and not all editors support line numbering, the results page will also show you a numbered listing of your script. </p>
<form enctype="multipart/form-data" action="do-syntax-check.php" method="POST">
    <!-- MAX_FILE_SIZE must precede the file input field -->
    <blockquote>
      <table>
      <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
      <!-- Name of input element determines name in $_FILES array -->
      <tr><td><span class="bold"> 1. Select file to check:</span></td>
          <td><input name="phpfile" type="file" />
      </td></tr>
      <tr>
        <td class="bold"> 2. Check syntax:</td>    
          <td><input type="submit" value="Check this File" />
      </td></tr>
	  </table>
    </blockquote>
</form>
<p>You can download this script (tarball): <a href="php-syntax-check.tar.gz">php-syntax-check.tar.gz</a><br>
  It will need some configuring for your system. </p>
 <hr>
<table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr>
      
    <td align="left"><font
size="-1">http://www.meandeviation.com/tutorials/learnphp/php-syntax-check/</font> 
    </td>
      
    <td align="right"><font size="-1"><a
href="http://www.hcibook.com/alan/">Alan Dix</a> &copy; 2005</font> </td>
    </tr>
</table>

</body>
</html>
