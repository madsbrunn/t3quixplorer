<?php
//
//  php-syntax-check (c) Alan Dix 2005
//
//  www.meandeviation.com
//
//  You are free to use and alter this scriopt for personal purposes.
//  If you distruibute this script or a modified version of it please include an appropriate
//  acknowledgement including the meandeviation URL.  
//
//  Note this script requires:
//
//     (1) command line installation of PHP
//         some PHP installations only include an APACHE or other moduel out of the box.
//         If this is the case you will need to hand compile the PHP (see www.php.net or documetnation)
//         or find a precompiled installation for command line use.
//         The path for PHP in $cmd will need to be altered for your system.
//         Also I assume the "-l" command line parameter which means "please syntax check only"
//         does not change between versions of PHP ... but best to check.
//         For Windows installations you will need to use the DOS equivalent "\l" perhaps???
//
//     (2) dos2unix and mac2unix converters
//         These are used to put everything into unix line format so that PHP reports syntax
//         errors on the correct lines!
//         These are standard in Linux distriobutions I believe.
//         On my system these are part of the standrd path, but if you have to isntall them
//         somewhere yourself then you will need explicit paths in $convert
//         If you install this on a Windows system you will have to do this conversion differently,
//         perhaps just read the text into a big PHP string and do translations in PHP, or use
//         equivalent DOS commands.
//         
//

include "config.php";

$upload_name = $_FILES['phpfile']['tmp_name'];
$name = $_FILES['phpfile']['name'];
$hname = htmlentities($name);

$is_uploaded = is_uploaded_file($upload_name);

if ( !$is_uploaded ) {
	echo "Sorry! bad URL :-(";
	exit(1);
}


$tmp_name = tempnam( TMPDIR, "SYNCHK");

// first convert to platform native line endings
// this could be done in pure PHP, but I'm using external programs as they are available on my system

$convert = DOS2UNIX . " < $upload_name | " . MAC2UNIX . " > $tmp_name";

exec($convert,$cvout,$cvres);  

// now run command line PHP in syntax check only mode (the '-l' flag)

$cmd = PHP_CMD . " -l $tmp_name";

exec($cmd,$output,$result);
$len = count($output);
if ( $len <= 0 ) {
	echo "Sorry! internal error, no syntax check output :-(";
	exit(1);
}

// finally parse output of syntax check

if ( substr($output[0],0,strlen(OK_LINE_START)) == OK_LINE_START ) {
	$syntax_OK = true;
	$title = "PHP syntax check: $hname is OK :-)";
} else {
	$syntax_OK = false;
	$title = "PHP syntax check: $hname FAILED :-(";
	$filtered_output = array();
	$err_line_nos = array();
	if ( $len > 0 && rtrim($output[0]) == "<br />" )  {
		array_shift($output);
		$len--;
	}
	if ( $len > 0 && rtrim($output[$len-1]) == "Errors parsing " . $tmp_name )  {
		$len--;   // N.B. skip last line
	}
	for ( $i=0; $i < $len; $i++ ) {
		$line = $output[$i];
		$filtered_output[] = str_replace($tmp_name,$hname,$line);
		if ( preg_match(ON_LINE_PATTERN, $line, $matches) ) {
			$err_line_nos[] = $matches[1];
		}
	}
	sort($err_line_nos);
	$err_line_ct = count($err_line_nos);
}

$contents = file($tmp_name);

unlink($tmp_name);

function error_list() {
	global $filtered_output;
	$i=0;
	foreach ( $filtered_output as $line ) {
		$i++;
		echo $line ."\n";
	}
}

function source_list() {
	global $contents, $err_line_nos;
	$i=0;
	foreach ( $contents as $line ) {
		$i++;
		$line_nos = str_pad($i,3," ",STR_PAD_LEFT);
		$numbered_line = $line_nos . ": " . htmlentities(rtrim($line));
		if ( in_array($i,$err_line_nos) ) {
			echo  ERR_PREFIX . "<font color=\"" . HIGHLIGHT_COLOR . "\">" . $numbered_line ."</font>\n";
		} else  {
			echo  OK_PREFIX . $numbered_line ."\n";
		}
	}
}

if ( $syntax_OK ) {
	include "html/syntax-ok.php";
} else {
	include "html/syntax-bad.php";
}

?>